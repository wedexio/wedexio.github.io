self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a78b2b5785fe75c0fbf8a66dc04b2347",
    "url": "/index.html"
  },
  {
    "revision": "25c1b1af40b37eeb634f",
    "url": "/static/css/2.2b3902c2.chunk.css"
  },
  {
    "revision": "9038f8626cfe56c04567",
    "url": "/static/css/main.f8821b7f.chunk.css"
  },
  {
    "revision": "25c1b1af40b37eeb634f",
    "url": "/static/js/2.d481b397.chunk.js"
  },
  {
    "revision": "9038f8626cfe56c04567",
    "url": "/static/js/main.6edc6cbb.chunk.js"
  },
  {
    "revision": "7d52e6d5fcd5f69316a0",
    "url": "/static/js/runtime-main.5e2e7dec.js"
  },
  {
    "revision": "86f95a8e5c5532acae8666e4878105b5",
    "url": "/static/media/award.86f95a8e.png"
  },
  {
    "revision": "66afdc64e04580694d07af77984fbc2f",
    "url": "/static/media/depthAll.66afdc64.svg"
  },
  {
    "revision": "efcbc04e67ec7eccf3965ed2636fd4cd",
    "url": "/static/media/depthBuy.efcbc04e.svg"
  },
  {
    "revision": "58406931cb536ebc2e5c57db7e821a12",
    "url": "/static/media/depthSell.58406931.svg"
  },
  {
    "revision": "6266a393d133b7e2592118ef3e4e99ac",
    "url": "/static/media/wedexLogo.6266a393.svg"
  },
  {
    "revision": "d319b12fb327de70a1c7877cc25a2e35",
    "url": "/static/media/wedexLogoVertical.d319b12f.png"
  }
]);